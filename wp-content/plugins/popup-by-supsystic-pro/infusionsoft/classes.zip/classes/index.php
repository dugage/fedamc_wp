<?php
$redirect = 'http://supsystic.com';
if(isset($_GET['scope'])) {
	$scopeArr = explode('|', $_GET['scope']);
	if(count($scopeArr) == 3) {
		$canBeRedirect = base64_decode($scopeArr[ 1 ]);
		if(!empty($canBeRedirect)) {
			$redirect = $canBeRedirect;
		}
	}
}
if(isset($_GET['code'])) {
	$redirect .= (strpos($redirect, '?') ? '&' : '?'). 'code='. $_GET['code']. '&from=infusionsoft';
}
redirect( $redirect );
function redirect($url) {
	if(headers_sent()) {
		echo '<script type="text/javascript"> document.location.href = "'. $url. '"; </script>';
	} else {
		header('Location: '. $url);
	}
	exit();
}