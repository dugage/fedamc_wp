<?php

namespace Infusionsoft;

class TokenExpiredException extends InfusionsoftException {}