<!DOCTYPE html>
<html lang="es">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Star Admin Free Bootstrap-4 Admin Dashboard Template</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo e(asset('fedamc/vendors/iconfonts/mdi/css/materialdesignicons.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('fedamc/vendors/css/vendor.bundle.base.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('fedamc/vendors/css/vendor.bundle.addons.css')); ?>">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo e(asset('fedamc/css/style.css')); ?>">
  <!-- endinject -->
  <link rel="shortcut icon" href="<?php echo e(asset('fedamc/images/favicon.png')); ?>" />
  <style type="text/css">
    <?php echo $__env->yieldContent('custom-css'); ?>
  </style>
</head>

<body>
  <div class="container-scroller">

    <!-- partial:../../partials/_navbar.html -->
    <?php echo $__env->make('layout.parts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- end partial-navbar -->

    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:../../partials/_sidebar.html -->
      
      <?php echo $__env->make('layout.parts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      
      <!-- partial -->
      <div class="main-panel">

        <!-- content-wrapper -->
        <div class="content-wrapper">
          <?php echo $__env->yieldContent('content'); ?>
        </div>
        <!-- content-wrapper ends -->

        <!-- partial:../../partials/_footer.html -->
        <?php echo $__env->make('layout.parts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- partial -->

      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- JS PERSONALIZADO -->
  <?php echo $__env->yieldContent('custom-js'); ?>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="<?php echo e(asset('fedamc/vendors/js/vendor.bundle.base.js')); ?>"></script>
  <script src="<?php echo e(asset('fedamc/vendors/js/vendor.bundle.addons.js')); ?>"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="<?php echo e(asset('fedamc/js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(asset('fedamc/js/misc.js')); ?>"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <!-- End custom js for this page-->
</body>

</html>
