<?php $__env->startSection('content-title'); ?>
	Lista de Maestros
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-description'); ?>
	Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('form-button'); ?>
	href="<?php echo e(route('maestros.nuevo')); ?>"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('table-head'); ?>
	
	<th>Usuario</th>
	<th>Nombre</th>
	<th>Correo Electrónico</th>
	<th>Estado</th>
	<th>Licencia</th>
	<th>Acciones</th>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('table-body'); ?>

	<?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
		    <td class="py-1">
		      <img src="<?php echo e(asset('fedamc/images/faces-clipart/pic-1.png')); ?>" alt="image">
		    </td>
		    <td>
		      <?php echo e($teacher->name); ?>

		    </td>
		    <td>
		      <?php echo e($teacher->email); ?>

		    </td>
		    <td>
		    	<?php if($teacher->active == 0): ?>
		    		<label class="badge badge-danger">Inactivo</label>
		    	<?php else: ?>
		    		<label class="badge badge-success">Activo</label>
		    	<?php endif; ?>
		      
		    </td>
		    <td>
		      <strong>#<?php echo e($teacher->license); ?></strong>
		    </td>
		    <td>
		    	<div class="btn-group" role="group" aria-label="Basic example">
	              <a href="<?php echo e(route('maestros.editar', ['teachers' => $teacher->id])); ?>" class="btn btn-outline-secondary px-2">
	              	<i class="mdi mdi-pencil"></i>
	              </a>
	              <a href="<?php echo e(route('maestros.ver', ['teachers' => $teacher->id])); ?>" class="btn btn-outline-secondary px-2">
					<i class="mdi mdi-eye"></i>
	              </a>
	              <button id="boton-eliminar" class="btn btn-outline-secondary px-2" onclick="document.getElementById('<?php echo e($teacher->id); ?>').submit()">
					<i class="mdi mdi-delete"></i>
	              </button>

	              <form class="d-none" id="<?php echo e($teacher->id); ?>" method="POST" action="<?php echo e(route('maestros.eliminar', ['teachers' => $teacher->id])); ?>">
                        @csrf
                        @method('DELETE')
                   </form>
	            </div>
		    </td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.table', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>