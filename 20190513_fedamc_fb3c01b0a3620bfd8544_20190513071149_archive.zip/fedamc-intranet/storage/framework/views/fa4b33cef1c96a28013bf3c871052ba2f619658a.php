  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="<?php echo e(asset('fedamc/vendors/js/vendor.bundle.base.js')); ?>"></script>
  <script src="<?php echo e(asset('fedamc/vendors/js/vendor.bundle.addons.js')); ?>"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="<?php echo e(asset('fedamc/js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(asset('fedamc/js/misc.js')); ?>"></script>
  <!-- endinject -->
</body>

</html>