<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Studends;
use App\Teacher;
use App\User;

class StudendsController extends Controller
{

    public function index(){

    	$data = Studends::all();
    	return view('studends.index')->with('studends', $data);

    }

    public function new(Request $request){

        dd($request->all());
    	$data = $request->validate([
    		'name' => 'required',
    		'lastname' => 'required',
    		'email' => 'required|email|unique:users,email',
    		'license' => 'numeric',
    		'profilePicture' => 'image',
            'password' => 'required',
            'phone' => 'numeric|min:9',
            'fNacimiento' => 'date',
            'activity' => '',
            'address' => '',
            'cp' => 'numeric|min:5',
            'city' => '',
            'active' => 'required',
            'rate' => 'numeric',
            'idUser' => '',
            'idMaster' => '',
    	]);
    	$user = User::create($data);
   		$data['idUser'] = $user->id;
        $data['password'] = bcrypt('password');

    	if ($request->hasFile('profilePicture')) {
   			$data['profilePicture'] = $request->file('profilePicture')->store('public/profiles');
   		}
   		$studend = Studends::create($data);
   		return redirect()->route('federados');
    }

    public function show(Studends $studends){
        $data = $studends;
        return view('studend.show')->with('studend',$data);
    }

    public function edit(Studends $studends){
    	$data = $studends;
        return view('studends.edit')->with('studend',$data);
    }

    public function update(Request $request, Studends $studends){

    	$data = $request->validate([
            'name' => 'required',
            'lastname' => 'required',
            'email' => 'required|email|unique:users,email,'.$studends->user->id,
            'license' => '',
            'profilePicture' => 'image',
            'password' => '',
            'phone' => '',
            'fNacimiento' => 'date',
            'address' => '',
            'cp' => 'numeric|min:5',
            'city' => '',
            'activity' => '',
            'active' => 'required',
            'rate' => 'numeric',
            'idUser' => '',
        ]);

        if ($data['password'] != null) {
            $data['password'] = bcrypt($data['password']);
        }else{
            unset($data['password']);
        }

   		if ($request->hasFile('profilePicture')) {
   			$data['profilePicture'] = $request->file('profilePicture')->store('public/profile');
   		}

        $studends->user->update($data);
        $studends->update($data);

        return redirect()->route('federados.ver',['studend' => $studends])->with('info','Perfil acualizado');

    }

    public function delete(Studends $studends){
        $idUser = $studends->user->id;
        $studends->delete();
        User::find($idUser)->delete();

        return redirect()->route('federados')->with('info', 'Usuario Eliminado');
    }

}
