<?php

namespace App\Http\Controllers;
use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Teachers;
use App\Studends;


class UserController extends Controller
{
    
    public function index(){

    	$data = User::all();
    	return view('users.index')->with('users', $data);

    }

    public function new(Request $request){
    	$data = $request->validate([
    		'name' => 'required',
    		'lastname' => 'required',
    		'email' => 'required|email|unique:users,email',
    		'license' => '',
    		'profilePicture' => 'image',
            'password' => 'required',
            'typeUser' => '',
    	]);

        $data['password'] = bcrypt('password');

    	if ($request->hasFile('profilePicture')) {
   			$data['profilePicture'] = $request->file('profilePicture')->store('public/profiles');
   		}

   		$user = User::create($data);

        if ($data['typeUser'] == 'maestro') {
            $insert = new Teachers;
            $insert->name = $data['name'];
            $insert->lastname = $data['lastname'];
            //$insert->license = $data['license'];
            //$insert->profilePicture = $data['profilePicture'];
            $insert->email = $data['email'];
            $insert->idUser = $user->id;
            $insert->save();
        }elseif($data['typeUser'] == 'federado'){
            $insert = new Studends;
            $insert->name = $data['name'];
            $insert->lastname = $data['lastname'];
            //$insert->license = $data['license'];
            $insert->profilePicture = $data['profilePicture'];
            $insert->email = $data['email'];
            $insert->idUser = $user->id;
            $teacher->save();
        }

   		return redirect()->route('usuarios');
    }

    public function show(User $user){
        $data = $user;
        return view('users.show')->with('user',$data);
    }

    public function edit(User $user){
    	$data = $user;
        return view('users.edit')->with('user',$data);
    }

    public function update(Request $request, User $user){

    	$data = $request->validate([
    		'name' => 'required',
            'lastname' => 'required',
            'email' => 'required|email|unique:users,email,'.$user->id,
            'license' => '',
            'profilePicture' => 'image',
            'password' => '',
    	]);

        if ($data['password'] != null) {
            $data['password'] = bcrypt($data['password']);
        }else{
            unset($data['password']);
        }

   		if ($request->hasFile('profilePicture')) {
   			$data['profilePicture'] = $request->file('profilePicture')->store('public/profile');
   		}

        $user->update($data);
        return redirect()->route('usuarios.ver',['user' => $user])->with('info','Perfil acualizado');
    }

    public function delete(User $user){
        
        if ($user->teacher != null) {
            $user->teacher->delete();
        }elseif($user->studend != null){
            $user->studen->delete();
        }

        $user->delete();

        return redirect()->route('usuarios')->with('info', 'Usuario Eliminado');
    }



}
