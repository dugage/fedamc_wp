<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Teachers;
use App\User;

class TeachersController extends Controller
{
    
    public function index(){

    	$data = Teachers::all();
    	return view('teachers.index')->with('teachers', $data);

    }

    public function new(Request $request){
    	$data = $request->validate([
    		'name' => 'required',
    		'lastname' => 'required',
    		'email' => 'required|email|unique:users,email',
    		'license' => 'numeric',
    		'profilePicture' => 'image',
            'password' => 'required',
            'phone' => 'numeric|min:9',
            'fNacimiento' => 'date',
            'activity' => '',
            'address' => '',
            'cp' => 'numeric|min:5',
            'city' => '',
            'active' => 'required',
            'rate' => 'numeric',
            'idUser' => '',
    	]);
    	$user = User::create($data);
   		$data['idUser'] = $user->id;
        $data['password'] = bcrypt('password');

    	if ($request->hasFile('profilePicture')) {
   			$data['profilePicture'] = $request->file('profilePicture')->store('public/profiles');
   		}
   		$teacher = Teachers::create($data);
   		return redirect()->route('maestros');
    }

    public function show(Teachers $teachers){
        $data = $teachers;
        return view('teachers.show')->with('teacher',$teachers);
    }

    public function edit(Teachers $teachers){
    	$data = $teachers;
        return view('teachers.edit')->with('teacher',$data);
    }

    public function update(Request $request, Teachers $teachers){

    	$data = $request->validate([
            'name' => 'required',
            'lastname' => 'required',
            'email' => 'required|email|unique:users,email,'.$teachers->user->id,
            'license' => '',
            'profilePicture' => 'image',
            'password' => '',
            'phone' => '',
            'fNacimiento' => 'date',
            'address' => '',
            'cp' => 'numeric|min:5',
            'city' => '',
            'activity' => '',
            'active' => 'required',
            'rate' => 'numeric',
            'idUser' => '',
        ]);

        if ($data['password'] != null) {
            $data['password'] = bcrypt($data['password']);
        }else{
            unset($data['password']);
        }

   		if ($request->hasFile('profilePicture')) {
   			$data['profilePicture'] = $request->file('profilePicture')->store('public/profile');
   		}

        $teachers->user->update($data);
        $teachers->update($data);

        return redirect()->route('maestros.ver',['teacher' => $teachers])->with('info','Perfil acualizado');

    }

    public function delete(Teachers $teachers){
        $idUser = $teachers->user->id;
        $teachers->delete();
        User::find($idUser)->delete();

        return redirect()->route('maestros')->with('info', 'Usuario Eliminado');
    }

}
