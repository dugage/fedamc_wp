<footer class="footer">
  <div class="container-fluid clearfix">
    <span class="d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018
      <a class="text-danger" href="http://www.bootstrapdash.com/" target="_blank">Fedamc</a>. Todos los derechos reservados.</span>
    <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Proyecto realizado por CREAMERITO
      <i class="mdi mdi-heart text-danger"></i>
    </span>
  </div>
</footer>