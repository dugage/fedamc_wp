  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="{{ asset('fedamc/vendors/js/vendor.bundle.base.js') }}"></script>
  <script src="{{ asset('fedamc/vendors/js/vendor.bundle.addons.js') }}"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="{{ asset('fedamc/js/off-canvas.js') }}"></script>
  <script src="{{ asset('fedamc/js/misc.js') }}"></script>
  <!-- endinject -->
</body>

</html>