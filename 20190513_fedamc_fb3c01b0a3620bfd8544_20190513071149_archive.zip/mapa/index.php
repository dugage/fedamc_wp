<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Base de datos de Clubes de FEAMC</title>
<style type="text/css">
<!--
body,td,th {
	font-family: Verdana;
	font-size: 11px;
}

div.estilo {
	border: 2px solid #990000;
	padding: 5px;
	background-color: #333333;
	width: 30%;
}
h2 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	font-weight: bold;
}

div.estilo2 {
	border: 2px solid #999999;
	padding: 5px;
	background-color: #000000;
	width: 30%;
	font-size: 14px;
}

input, textarea, select {
  border:1px solid #aaaaaa;
  background:#ffffff url(textbg.gif) top left no-repeat;
  margin-top:2px;
}

a:link {
	color: #FFFFFF;
	font-weight: bold;
	font-family: Arial;
	font-size: 12px;
}
a:visited {
	color: #999999;
	font-weight: bold;
	font-family: Arial;
}
a:hover {
	color: #CCCCCC;
	font-weight: bold;
	font-family: Arial;
}
a:active {
	font-size: 13px;
	font-family: Arial;
}
-->
</style>
</head>

<body>
<div align="center">
  <h2>Clubes y Entidades Adheridas<br />
  <br />
  </h2>
</div>
<div align="center">
  <table border="0">
    <tr>
      <td>
        <div align="center" id="menu" class="estilo" style="width: 250px" onmouseover="this.className='estilo2'" onmouseout="this.className='estilo'">
          <a href="mapaspain.php">Clubes Asociados de Espa�a</a>        
</div>    </td>
    <td>
      <div align="center" id="menu2" class="estilo" style="width: 250px" onmouseover="this.className='estilo2'" onmouseout="this.className='estilo'">
        <a href="index.php?v=mundo">Representaciones Internacionales</a>        </div>    </td>
    </tr>
  </table>
  <br />
  <br />
</div>
</body>

</html>
