﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"[]>
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US" xml:lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>Clubes y Entidades Adheridas</title>



    <link rel="stylesheet" href="style.css" type="text/css" media="screen" />
    <!--[if IE 6]><link rel="stylesheet" href="style.ie6.css" type="text/css" media="screen" /><![endif]-->
    <!--[if IE 7]><link rel="stylesheet" href="style.ie7.css" type="text/css" media="screen" /><![endif]-->

    <script type="text/javascript" src="jquery.js"></script>
    <script type="text/javascript" src="script.js"></script>
	<script language="JavaScript" type="text/javascript" src="js.js"></script>
<style type="text/css">
<!--
body,td,th {
	font-family: Verdana;
	font-size: 11px;
}
-->
</style>

</head>
<body>
<div id="art-page-background-glare-wrapper">
    <div id="art-page-background-glare"></div>
</div>
<div id="art-main">
    <div class="cleared reset-box"></div>
    <div class="art-box art-sheet">
        <div class="art-box-body art-sheet-body">
            <div class="art-header" style="width: 1094px; margin-top: 9px;">
                <div class="art-headerobject"></div>
                        <div class="art-logo">
                                                                        </div>
                
            </div>
	<table align="center" border="0" cellpadding="4" cellspacing="4" height="96" style="background-color:white; margin-left: 130px;" width="770">

	<tbody>
		<tr>
			<td style="width: 70px; text-align: center;">
				<a href="http://www.martialartsalliance.eu/" target="_blank"><img alt="" src="l1.png" /></a></td>
			
			<td style="width: 66px;">
				<a href="http://www.casakoreaworldhapkidofederation.org/mijoomla/" target="_blank"><img alt="" src="l3.png" /></a></td>
			<td style="width: 40px;">
				<a href="http://www.fdtaekwondo.it/"><img alt="" src="l4.png" /></a></td>
			<td>
				<a href="http://www.kukkiwon.or.kr/eng/index.action" target="_blank"><img alt="" src="l5.png" /></a></td>
			<td style="width: 31px;">
				<a href="http://f.c.t.francais.free.fr/" target="_blank"><img alt="" src="l6.png" /></a></td>
			<td style="width: 4px;">
				<a href="http://www.asdiam.it/" target="_blank"><img alt="" src="l7.png" /></a></td>
			<td style="width: 1px;">
				<a href="http://www.tagb.biz/" target="_blank"><img alt="" src="l8.png" /></a></td>
			<td style="width: 0px;">
				<a href="http://www.wtf.org/" target="_blank"><img alt="" src="l9.png" /></a></td>
			<td style="width: 39px;">
				<a href="http://www.martialartsalliance.eu/" target="_blank"><img alt="" src="logoemma.png" /></a></td>
			<td style="width: 40px;">
				<a href="http://www.koreantotalcontactworldfederation.com/" target="_blank"><img alt="" src="logult.png" /></a></td>
		</tr>
	</tbody>
</table>		
            <div class="cleared reset-box"></div>
            <div class="art-layout-wrapper">
                <div class="art-content-layout">
                    <div class="art-content-layout-row">
                        <div class="art-layout-cell art-sidebar1">
						<div style="align:center">

</div>
<div class="art-box art-vmenublock">
    <div class="art-box-body art-vmenublock-body">
                <div class="art-bar art-vmenublockheader">
                    <h3 class="t">Menú Vertical</h3>
                </div>
                <div class="art-box art-vmenublockcontent">
                    <div class="art-box-body art-vmenublockcontent-body">
                <ul class="art-vmenu">
	<li>
		<a href="http://fedamc.es/index.php?option=com_content&view=category&layout=blog&id=9&Itemid=101">Principal</a>
	</li>	
	<li>
		<a href="http://fedamc.es/index.php?option=com_content&view=category&layout=blog&id=10&Itemid=132">Cursos y Eventos</a>
	</li>	
	<li>
		<a href="http://fedamc.es/index.php?option=com_content&view=category&layout=blog&id=11&Itemid=133">Nuestra Trayectoria</a>
	</li>	
	<li>
		<a href="http://fedamc.es/index.php?option=com_content&view=article&id=11&Itemid=134">La Federación</a>
		
	</li>	
	<li>
		<a href="http://fedamc.es/index.php?option=com_content&view=article&id=12&Itemid=135">Comité</a>
		
	</li>	
	<li>
		<a href="http://fedamc.es/index.php?option=com_content&view=article&id=13&Itemid=136">Exámenes</a>
	</li>	
	<li>
		<a href="http://fedamc.es/index.php?option=com_content&view=article&id=14&Itemid=137">Clubes y Entidades Adheridas</a>
	</li>	
	<li>
		<a href="http://fedamc.es/index.php?option=com_content&view=article&id=15&Itemid=138">Forma parte de la Federación</a>
	</li>	
		<li>
		<a href="http://fedamc.es/index.php?option=com_content&view=article&id=16&Itemid=139">Escuelas Nacionales</a>
	</li>
		<li>
		<a href="http://fedamc.es/index.php?option=com_content&view=article&id=17&Itemid=140">Documentación Federativa</a>
	</li>
		<li>
		<a href="http://fedamc.es/index.php?option=com_content&view=article&id=18&Itemid=141">Te ofrecemos</a>
	</li>
		<li>
		<a href="http://fedamc.es/index.php?option=com_content&view=article&id=19&Itemid=142">Enlaces</a>
	</li>
		<li>
		<a href="http://fedamc.es/index.php?option=com_chronoforms&view=form&Itemid=143">Contacto</a>
	</li>
	</li>
		<li>
		<a href="http://fedamc.es/index.php?option=com_content&view=article&id=20&Itemid=144">Sponsors Oficiales</a>
	</li>
</ul>
                
                                		<div class="cleared"></div>
                    </div>
                </div>
		<div class="cleared"></div>
    </div>
</div>
                          <div class="cleared"></div>
                        </div>
                        <div class="art-layout-cell art-content">
<div class="art-box art-post">
    <div class="art-box-body art-post-body">
<div class="art-post-inner art-article">

<div align="center">
  <script type="text/javascript" src="wz_tooltip.js"></script>
  <script language="javascript">
	window.onload=function(){
		cargarmapas(54);
	}
 </script>
  <table width="550" height="138" border="0" cellpadding="0" cellspacing="0" style="margin-top:20px; margin-left: 136px; ">
    <tr>
      <td><img src="mapa0.gif" name="mapa" width="398" height="290" border="0" usemap="#Mapa" class="float" id="mapa">
  <map name="Mapa" id="Mapa">
    <area id="1" shape="poly" coords="176,40,182,40,183,44,199,48,197,53,198,56,194,56,195,60,191,60,189,57,184,56,179,50,181,47" href="#" onfocus="blur();" onmouseover="cambiar('mapa',1); Tip('Alava');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('ALAVA');">
    <area id="2" shape="poly" coords="188,157,197,161,208,159,215,157,221,157,225,160,222,167,228,171,230,178,224,178,217,178,215,183,214,188,210,188,204,188,198,195,196,197,192,196,192,187,190,183,187,182,186,168,187,162" href="#" onfocus="blur();" onmouseover="cambiar('mapa',2);Tip('Albacete');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('ALBACETE');">
    <area id="3" shape="poly" coords="229,179,237,178,241,174,248,173,253,172,257,175,253,179,248,182,245,184,240,191,238,191,238,198,233,203,229,198,229,189,228,187,229,180" href="#" onfocus="blur();" onmouseover="cambiar('mapa',3);Tip('Alicante');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('ALICANTE');">
    <area id="4" shape="poly" coords="179,235,181,225,187,220,194,213,197,204,199,204,204,204,205,210,211,218,209,224,208,228,202,235,195,233,190,235,180,235" href="#" onfocus="blur();" onmouseover="cambiar('mapa',4);Tip('Almeria');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('ALMERIA');">
    <area id="5" shape="poly" coords="87,27,86,32,93,40,90,44,92,46,99,47,102,43,112,42,115,46,118,41,127,42,136,37,140,38,145,33,128,28,115,24" href="#" onfocus="blur();" onmouseover="cambiar('mapa',5);Tip('Asturias');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('ASTURIAS');">
    <area id="6" shape="poly" coords="114,128,121,125,127,119,132,112,132,104,142,105,149,118,155,116,146,129,146,132,142,132,139,130,134,135,128,136,126,130,120,131" href="#" onfocus="blur();" onmouseover="cambiar('mapa',6);Tip('Avila');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('AVILA');">
    <area id="7" shape="poly" coords="84,164,89,165,88,171,81,177,80,183,84,189,88,191,99,196,108,197,113,191,117,191,120,188,119,183,133,176,134,173,136,169,134,166,136,163,139,160,139,156,136,155,133,155,128,159,122,162,117,165,110,163,107,167,102,162,91,162,87,158,85,158,83,160" href="#" onfocus="blur();" onmouseover="cambiar('mapa',7);Tip('Badajoz');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('BADAJOZ');">
    <area id="8" shape="poly" coords="334,124,267,178,310,184,357,139" href="#" onfocus="blur();" onmouseover="cambiar('mapa',8);Tip('Baleares');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('BALEARES');">
    <area id="54" shape="poly" coords="291,101,292,98,288,93,288,86,293,83,294,70,299,70,301,74,307,75,309,81,306,83,312,89,307,94,303,98,296,99" href="#" onfocus="blur();" onmouseover="cambiar('mapa',54);Tip('Barcelona');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('BARCELONA');">
    <area id="10" shape="poly" coords="157,54,164,52,163,44,169,42,175,42,178,46,177,52,180,56,178,58,177,69,182,76,178,82,173,80,168,90,163,91,159,90,159,84,162,76,156,71,153,65,153,57" href="#" onfocus="blur();" onmouseover="cambiar('mapa',10);Tip('Burgos');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('BURGOS');">
    <area id="11" shape="poly" coords="80,154,76,150,81,148,86,147,88,140,89,137,87,133,90,130,102,129,105,124,111,130,117,130,119,133,125,131,126,137,126,140,128,144,131,145,130,151,130,155,123,160,115,165,107,165,98,161,92,159,85,155,81,158" href="#" onfocus="blur();" onmouseover="cambiar('mapa',11);Tip('Caceres');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('CACERES');">
    <area id="12" shape="poly" coords="101,235,104,233,109,233,116,231,122,231,126,228,131,231,127,235,122,241,118,243,126,245,126,249,122,255,117,255,109,250,105,243,101,236" href="#" onfocus="blur();" onmouseover="cambiar('mapa',12);Tip('Cadiz');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('CADIZ');">
    <area id="13" shape="poly" coords="146,32,147,35,140,38,140,42,145,43,148,42,157,51,162,50,161,43,169,39,171,40,171,36,177,33,167,28" href="#" onfocus="blur();" onmouseover="cambiar('mapa',13);Tip('Cantabria');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('CANTABRIA');">
    <area id="14" shape="poly" coords="232,142,235,136,239,132,242,130,245,126,244,122,242,120,245,118,248,116,253,118,257,116,260,120,263,123,248,148,245,145,241,147,236,145" href="#" onfocus="blur();" onmouseover="cambiar('mapa',14);Tip('Castellon');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('CASTELLON');">
    <area id="15" shape="poly" coords="114,263,114,268,119,268,123,264,122,263,116,261,113,261" href="#" onfocus="blur();" onmouseover="cambiar('mapa',15);Tip('Ceuta');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('CEUTA');">
    <area id="16" shape="poly" coords="140,162,141,155,149,154,155,151,154,157,163,160,169,158,175,154,180,154,186,157,184,164,184,168,187,176,186,181,184,183,175,183,170,185,162,189,158,189,153,189,148,185,140,182,134,178,136,172,138,168,138,165" href="#" onfocus="blur();" onmouseover="cambiar('mapa',16);Tip('Ciudad Real');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('CIUDAD REAL');">
    <area id="17" shape="poly" coords="135,178,129,182,123,183,122,191,123,198,126,206,133,206,136,213,141,218,146,220,155,217,155,213,151,205,151,199,155,193,151,189,143,183,136,179" href="#" onfocus="blur();" onmouseover="cambiar('mapa',17);Tip('Cordoba');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('CORDOBA');">
    <area id="18" shape="poly" coords="179,138,180,134,186,132,186,128,192,127,193,123,198,121,205,122,206,125,209,128,212,132,216,135,222,140,222,147,219,147,215,152,214,157,207,158,202,157,200,159,194,158,190,157,183,155,184,147,180,139" href="#" onfocus="blur();" onmouseover="cambiar('mapa',18);Tip('Cuenca');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('CUENCA');">
    <area id="19" shape="poly" coords="294,61,298,62,302,64,305,62,313,64,319,61,327,62,330,68,327,71,329,79,319,88,314,85,311,86,307,83,309,75,307,72,300,72,301,68,296,67" href="#" onfocus="blur();" onmouseover="cambiar('mapa',19);Tip('Gerona');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('GERONA');">
    <area id="20" shape="poly" coords="147,222,157,228,164,235,174,235,177,233,179,225,184,220,190,218,193,213,196,207,197,200,191,197,186,200,183,204,183,211,178,211,175,211,174,211,168,211,156,217,155,217,150,225" href="#" onfocus="blur();" onmouseover="cambiar('mapa',20);Tip('Granada');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('GRANADA');">
    <area id="21" shape="poly" coords="215,120,214,112,206,104,203,105,195,106,187,102,176,100,171,103,172,118,178,127,180,133,190,123,202,118,208,125" href="#" onfocus="blur();" onmouseover="cambiar('mapa',21);Tip('Guadalajara');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('GUADALAJARA');">
    <area id="22" shape="poly" coords="192,43,196,35,204,34,210,32,211,34,206,39,202,46" href="#" onfocus="blur();" onmouseover="cambiar('mapa',22);Tip('Guipuzcoa');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('GUIPUZCOA');">
    <area id="23" shape="poly" coords="87,192,85,197,81,197,81,199,79,203,75,206,75,212,77,220,85,219,89,222,95,225,99,230,105,232,102,225,101,220,101,215,97,209,101,205,105,203,106,199,101,197,97,197,94,195,89,192" href="#" onfocus="blur();" onmouseover="cambiar('mapa',23);Tip('Huelva');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('HUELVA');">
    <area id="24" shape="poly" coords="235,47,242,50,245,48,251,53,256,52,266,53,268,59,268,69,263,80,259,85,261,91,258,91,257,94,251,96,248,89,245,87,241,83,240,78,233,75,237,66,232,65,231,57" href="#" onfocus="blur();" onmouseover="cambiar('mapa',24);Tip('Huesca');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('HUESCA');">
    <area id="25" shape="poly" coords="158,213,155,210,153,205,151,201,155,195,154,191,160,190,165,190,170,189,174,186,181,187,188,186,192,189,193,194,192,199,186,201,185,205,182,210,177,209,170,213,163,215,159,216" href="#" onfocus="blur();" onmouseover="cambiar('mapa',25);Tip('Jaen');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('JAEN');">
    <area id="26" shape="poly" coords="64,48,53,50,41,58,40,55,42,51,35,46,35,42,43,35,51,35,58,32,58,27,65,20,71,20,65,35" href="#" onfocus="blur();" onmouseover="cambiar('mapa',26);Tip('A Coru&ntilde;a');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('A CORUNA');">
    <area id="27" shape="poly" coords="181,57,181,61,179,69,183,76,185,72,188,75,193,71,199,73,204,78,206,75,210,71,204,66,193,62,187,59" href="#" onfocus="blur();" onmouseover="cambiar('mapa',27);Tip('La Rioja');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('LA RIOJA');">
    <area id="28" shape="poly" coords="89,244,50,269,54,283,84,273,90,255" href="#" onfocus="blur();" onmouseover="cambiar('mapa',28);Tip('Las Palmas');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('LAS PALMAS');">
    <area id="29" shape="poly" coords="89,59,92,49,100,48,103,45,111,45,114,48,118,45,136,40,138,44,136,48,136,61,133,67,126,70,125,75,122,75,119,70,94,70,96,66" href="#" onfocus="blur();" onmouseover="cambiar('mapa',29);Tip('Leon');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('LEON');">
    <area id="30" shape="poly" coords="268,53,269,48,285,53,287,61,293,60,295,66,290,67,290,78,289,82,284,83,283,90,278,92,274,96,263,99,260,95,262,92,266,92,262,88,264,83,269,74,272,63" href="#" onfocus="blur();" onmouseover="cambiar('mapa',30);Tip('Lerida');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('LERIDA');">
    <area id="31" shape="poly" coords="73,21,80,25,86,26,83,30,90,39,87,43,90,48,83,63,79,61,74,61,64,58,67,52,65,49,67,34" href="#" onfocus="blur();" onmouseover="cambiar('mapa',31);Tip('Lugo');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('LUGO');">
    <area id="32" shape="poly" coords="146,130,149,126,152,121,162,108,168,103,170,107,170,118,176,126,176,130,178,135,165,140,166,135,155,130" href="#" onfocus="blur();" onmouseover="cambiar('mapa',32); Tip('Madrid');" onmouseout="UnTip();cambiar('mapa',0); UnTip();" onclick="cargaMapa('MADRID');">
    <area id="33" shape="poly" coords="174,277,174,284,178,284,186,284,186,281,180,277,175,277" href="#" onfocus="blur();" onmouseover="cambiar('mapa',33);Tip('Melilla');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('MELILLA');">
    <area id="34" shape="poly" coords="134,228,141,221,148,221,152,228,160,233,163,236,150,236,142,241,135,242,129,246,122,243,134,231" href="#" onfocus="blur();" onmouseover="cambiar('mapa',34);Tip('Malaga');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('MALAGA');">
    <area id="35" shape="poly" coords="197,199,204,201,205,207,208,215,213,218,218,214,225,211,230,209,236,209,233,205,230,199,228,194,229,191,226,187,226,186,228,184,225,179,223,179,220,180,218,183,218,186,216,191,212,191,210,190,206,191,204,190,199,194,197,201" href="#" onfocus="blur();" onmouseover="cambiar('mapa',35); Tip('Murcia');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('MURCIA');">
    <area id="36" shape="poly" coords="213,35,219,35,218,41,221,41,231,46,234,46,233,49,231,54,225,56,221,60,221,68,218,71,220,78,217,80,208,76,209,74,213,71,205,65,196,61,196,58,199,50,207,42,209,38" href="#" onfocus="blur();" onmouseover="cambiar('mapa',36);Tip('Navarra');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('NAVARRA');">
    <area id="37" shape="poly" coords="87,74,83,75,83,78,76,80,69,79,64,79,61,81,58,78,61,73,59,71,61,68,58,60,64,60,71,63,78,64,85,66,86,60,89,60,92,65,88,69" href="#" onfocus="blur();" onmouseover="cambiar('mapa',37);Tip('Orense');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('ORENSE');">
    <area id="38" shape="poly" coords="141,44,138,49,139,58,135,68,138,72,136,78,140,79,143,78,149,82,156,82,159,77,154,72,151,64,150,56,156,52,148,44" href="#" onfocus="blur();" onmouseover="cambiar('mapa',38);Tip('Palencia');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('PALENCIA');">
    <area id="39" shape="poly" coords="59,68,56,72,48,75,43,79,43,72,47,68,45,67,44,58,53,53,63,51,66,53,63,58,56,60" href="#" onfocus="blur();" onmouseover="cambiar('mapa',39);Tip('Pontevedra');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('PONTEVEDRA');">
    <area id="40" shape="poly" coords="93,128,93,110,90,106,100,98,111,105,118,102,131,105,126,118,113,128,107,123,99,128" href="#" onfocus="blur();" onmouseover="cambiar('mapa',40);Tip('Salamanca');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('SALAMANCA');">
    <area id="41" shape="poly" coords="159,92,164,94,168,92,174,99,161,108,155,115,149,116,143,103,149,97" href="#" onfocus="blur();" onmouseover="cambiar('mapa',41);Tip('Segovia');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('SEGOVIA');">
    <area id="42" shape="poly" coords="104,230,102,222,102,213,102,209,99,209,105,205,110,202,107,197,116,192,119,195,122,199,123,203,123,209,132,205,134,212,138,218,135,223,127,227,119,229,112,232,105,233" href="#" onfocus="blur();" onmouseover="cambiar('mapa',42);Tip('Sevilla');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('SEVILLA');">
    <area id="43" shape="poly" coords="177,99,170,92,175,83,179,84,184,77,191,77,195,73,202,78,206,80,207,85,203,88,205,94,201,93,198,97,202,103,197,105,187,100" href="#" onfocus="blur();" onmouseover="cambiar('mapa',43);Tip('Soria');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('SORIA');">
    <area id="44" shape="poly" coords="25,239,20,280,42,275,64,253" href="#" onfocus="blur();" onmouseover="cambiar('mapa',44);Tip('Sta. Cruz de Tenerife');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('STA.CRUZ DE TENERIFE');">
    <area id="45" shape="poly" coords="264,122,257,116,260,112,258,106,262,100,274,99,278,94,284,92,288,100,278,106,269,114,272,117,266,118" href="#" onfocus="blur();" onmouseover="cambiar('mapa',45);Tip('Tarragona');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('TARRAGONA');">
    <area id="46" shape="poly" coords="211,126,213,121,217,123,217,111,226,105,235,106,239,101,240,100,251,106,257,107,255,116,248,113,240,120,243,124,241,130,237,130,231,139,224,138" href="#" onfocus="blur();" onmouseover="cambiar('mapa',46);Tip('Teruel');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('TERUEL');">
    <area id="47" shape="poly" coords="127,137,133,136,139,132,143,134,149,131,150,133,154,131,165,136,160,142,177,138,182,148,181,153,174,154,169,157,163,160,156,157,157,151,153,151,147,153,143,153,140,156,133,153,131,149,132,143,127,142,128,138" href="#" onfocus="blur();" onmouseover="cambiar('mapa',47);Tip('Toledo');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('TOLEDO');">
    <area id="48" shape="poly" coords="216,155,218,150,223,145,224,140,229,141,231,144,241,148,243,146,247,149,244,156,246,165,251,172,239,174,236,177,231,177,229,172,223,169,226,161,224,159,217,156" href="#" onfocus="blur();" onmouseover="cambiar('mapa',48);Tip('Valencia');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('VALENCIA');">
    <area id="49" shape="poly" coords="127,76,127,72,134,69,137,73,134,80,140,82,144,81,150,85,156,85,159,92,147,96,141,104,128,101,129,89" href="#" onfocus="blur();" onmouseover="cambiar('mapa',49);Tip('Valladolid');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('VALLADOLID');">
    <area id="50" shape="poly" coords="173,38,175,36,181,33,185,30,193,32,194,37,190,43,184,43,183,38" href="#" onfocus="blur();" onmouseover="cambiar('mapa',50);Tip('Vizcaya');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('VIZCAYA');">
    <area id="51" shape="poly" coords="88,77,89,71,104,71,118,72,121,77,126,77,127,90,126,103,113,100,111,103,107,100,99,97,107,88,102,84,99,85,99,78" href="#" onfocus="blur();" onmouseover="cambiar('mapa',51);Tip('Zamora');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('ZAMORA');">
    <area id="52" shape="poly" coords="214,109,206,100,204,101,201,96,205,95,207,88,211,85,208,78,218,81,223,75,220,70,223,61,228,56,230,63,229,70,234,68,229,76,233,79,237,81,246,90,249,97,258,98,255,104,242,98,237,98,237,102,230,103,220,104" href="#" onfocus="blur();" onmouseover="cambiar('mapa',52);Tip('Zaragoza');" onmouseout="UnTip();cambiar('mapa',0);" onclick="cargaMapa('ZARAGOZA');">
  </map></td>
      <td valign="top" bgcolor="#FFFFFF"><br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <br />
        <select name="provincias" id="provincias" onchange="cargaMapa(this.value)">
          <option value="" selected="selected">Seleccione una provincia</option>
          <option value="ALAVA">ALAVA</option>
          <option value="ALBACETE">ALBACETE</option>
          <option value="ALICANTE">ALICANTE</option>
          <option value="ALMERIA">ALMERIA</option>
          <option value="ASTURIAS">ASTURIAS</option>
          <option value="AVILA">AVILA</option>
          <option value="BADAJOZ">BADAJOZ</option>
          
          <option value="BALEARES">BALEARES</option>
          <option value="BARCELONA">BARCELONA</option>
          <option value="BURGOS">BURGOS</option>
          <option value="CACERES">CACERES</option>
          <option value="CADIZ">CADIZ</option>
          <option value="CANTABRIA">CANTABRIA</option>
          
          <option value="CASTELLON">CASTELLON</option>
          <option value="CIUDAD REAL">CIUDAD REAL</option>
          <option value="CORDOBA">CORDOBA</option>
          <option value="CUENCA">CUENCA</option>
          <option value="GERONA">GERONA</option>
          <option value="GRANADA">GRANADA</option>
          
          <option value="GUADALAJARA">GUADALAJARA</option>
          <option value="GUIPUZCOA">GUIPUZCOA</option>
          <option value="HUELVA">HUELVA</option>
          <option value="HUESCA">HUESCA</option>
          <option value="JAEN">JAEN</option>
          <option value="A CORUNA">A CORU&Ntilde;A</option>
          
          <option value="LA RIOJA">LA RIOJA</option>
          <option value="LAS PALMAS">LAS PALMAS</option>
          <option value="LEON">LEON</option>
          <option value="LERIDA">LERIDA</option>
          <option value="LUGO">LUGO</option>
          <option value="MADRID">MADRID</option>
          
          <option value="MALAGA">MALAGA</option>
          <option value="MELILLA">MALAGA</option>
          <option value="MURCIA">MURCIA</option>
          <option value="NAVARRA">NAVARRA</option>
          <option value="ORENSE">ORENSE</option>
          <option value="PALENCIA">PALENCIA</option>
          <option value="PONTEVEDRA">PONTEVEDRA</option>
          
          <option value="SALAMANCA">SALAMANCA</option>
          <option value="SEGOVIA">SEGOVIA</option>
          <option value="SEVILLA">SEVILLA</option>
          <option value="SORIA">SORIA</option>
          <option value="STA.CRUZ DE TENERIFE">STA.CRUZ DE TENERIFE</option>
          <option value="TARRAGONA">TARRAGONA</option>
          
          <option value="TERUEL">TERUEL</option>
          <option value="TOLEDO">TOLEDO</option>
          <option value="VALENCIA">VALENCIA</option>
          <option value="VALLADOLID">VALLADOLID</option>
          <option value="VIZCAYA">VIZCAYA</option>
          <option value="ZAMORA">ZAMORA</option>
          
          <option value="ZARAGOZA">ZARAGOZA</option>
        </select>  </td>
    </tr>
   </table>
  <br />
  <br />
</div>
<div align="center">
  <table width="575">
    <tr>
      <td width="567">
        <div align="right">
          <form id="busqueda" name="busqueda" action="" onsubmit="BuscaClub(); return false">
            Buscar Club: <input type="text" name="cadena" id="cadena" />
            <input type="submit" value="Buscar"/>
            </form>
	    </div>	    </td>
    </tr>
  </table>
</div>
<div id="resultado" style="width: 779px; margin-left: 84px;"></div>

</div>

</div>

		<div class="cleared"></div>
    </div>
</div>

                          <div class="cleared"></div>
                        </div>
                        <div class="art-layout-cell art-sidebar2">

<div style="margin-left: 518px;">
<p style="width: 384px; text-align: center; height: 79px; margin-left: -142px; font-size: 11px; color:black;">
Polígono Industrial Brenes C/Pilar de los Limones Nº 21 - CP:41410 - Carmona (Sevilla) 
Federación Registrada:Ministerio del Interior, Registro Nacional nº 50775, Grupo 1º, Sección 2 ª<br>
Email de contacto:  <a href="mailto:info@fedamc.es" target="_blank">info@fedamc.es</a>
	</p>
</div>	
                        </div>
                    </div>
                </div>
            </div>
            <div class="cleared"></div>
            <div class="art-footer">
                <div class="art-footer-body">
                            <div class="art-footer-text">
                                <p>Copyright © 2013. All Rights Reserved.</p>
                                                            </div>
                    <div class="cleared"></div>
                </div>
            </div>
    		<div class="cleared"></div>
        </div>
    </div>
    <div class="cleared"></div>
    <p class="art-page-footer"><a href="http://www.dugage.com" target="_blank">Diseño web Sevilla Dugage.</p>
    <div class="cleared"></div>
</div>

</body>
</html>
