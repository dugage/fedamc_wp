<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"[]>
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US" xml:lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>Clubes y Entidades Adheridas</title>



    <link rel="stylesheet" href="style.css" type="text/css" media="screen" />
    <!--[if IE 6]><link rel="stylesheet" href="style.ie6.css" type="text/css" media="screen" /><![endif]-->
    <!--[if IE 7]><link rel="stylesheet" href="style.ie7.css" type="text/css" media="screen" /><![endif]-->

    <script type="text/javascript" src="jquery.js"></script>
    <script type="text/javascript" src="script.js"></script>
	<script language="JavaScript" type="text/javascript" src="js.js"></script>
<style type="text/css">
<!--
body,td,th {
	font-family: Verdana;
	font-size: 11px;
}
-->
</style>

</head>
<body>
<div id="art-page-background-glare-wrapper">
    <div id="art-page-background-glare"></div>
</div>
<div id="art-main">

    <div class="cleared reset-box"></div>
    <div class="art-box art-sheet">
        <div class="art-box-body art-sheet-body">
            <div class="art-header" style="width: 1094px; margin-top: 9px;">
                <div class="art-headerobject"></div>
                        <div class="art-logo">
                                                                        </div>
                
            </div>
			<table align="center" border="0" cellpadding="4" cellspacing="4" height="96" style="background-color:white; margin-left: 130px;" width="770">

	<tbody>
		<tr>
			<td style="width: 70px; text-align: center;">
				<a href="http://www.martialartsalliance.eu/" target="_blank"><img alt="" src="l1.png" /></a></td>
			<td style="width: 61px;">
				<a href="http://www.famc.cat/" target="_blank"><img alt="" src="l2.png" /></a></td>
			<td style="width: 66px;">
				<a href="http://www.casakoreaworldhapkidofederation.org/mijoomla/" target="_blank"><img alt="" src="l3.png" /></a></td>
			<td style="width: 40px;">
				<a href="http://www.fdtaekwondo.it/"><img alt="" src="l4.png" /></a></td>
			<td>
				<a href="http://www.kukkiwon.or.kr/eng/index.action" target="_blank"><img alt="" src="l5.png" /></a></td>
			<td style="width: 31px;">
				<a href="http://f.c.t.francais.free.fr/" target="_blank"><img alt="" src="l6.png" /></a></td>
			<td style="width: 4px;">
				<a href="http://www.asdiam.it/" target="_blank"><img alt="" src="l7.png" /></a></td>
			<td style="width: 1px;">
				<a href="http://www.tagb.biz/" target="_blank"><img alt="" src="l8.png" /></a></td>
			<td style="width: 0px;">
				<a href="http://www.wtf.org/" target="_blank"><img alt="" src="l9.png" /></a></td>
			<td style="width: 39px;">
				<a href="http://www.martialartsalliance.eu/" target="_blank"><img alt="" src="logoemma.png" /></a></td>
			<td style="width: 40px;">
				<a href="http://www.koreantotalcontactworldfederation.com/" target="_blank"><img alt="" src="logult.png" /></a></td>
		</tr>
	</tbody>
</table>
            <div class="cleared reset-box"></div>
            <div class="art-layout-wrapper">
                <div class="art-content-layout">
                    <div class="art-content-layout-row">
                        <div class="art-layout-cell art-sidebar1">

<div class="art-box art-vmenublock">
    <div class="art-box-body art-vmenublock-body">
                <div class="art-bar art-vmenublockheader">
                    <h3 class="t">Menú Vertical</h3>
                </div>
                <div class="art-box art-vmenublockcontent">
                    <div class="art-box-body art-vmenublockcontent-body">
                <ul class="art-vmenu">
	<li>
		<a href="http://fedamc.es/index.php?option=com_content&view=category&layout=blog&id=9&Itemid=101">Principal</a>
	</li>	
	<li>
		<a href="http://fedamc.es/index.php?option=com_content&view=category&layout=blog&id=10&Itemid=132">Cursos y Eventos</a>
	</li>	
	<li>
		<a href="http://fedamc.es/index.php?option=com_content&view=category&layout=blog&id=11&Itemid=133">Nuestra Trayectoria</a>
	</li>	
	<li>
		<a href="http://fedamc.es/index.php?option=com_content&view=article&id=11&Itemid=134">La Federación</a>
		
	</li>	
	<li>
		<a href="http://fedamc.es/index.php?option=com_content&view=article&id=12&Itemid=135">Comité</a>
		
	</li>	
	<li>
		<a href="http://fedamc.es/index.php?option=com_content&view=article&id=13&Itemid=136">Exámenes</a>
	</li>	
	<li>
		<a href="http://fedamc.es/index.php?option=com_content&view=article&id=14&Itemid=137">Clubes y Entidades Adheridas</a>
	</li>	
	<li>
		<a href="http://fedamc.es/index.php?option=com_content&view=article&id=15&Itemid=138">Forma parte de la Federación</a>
	</li>	
		<li>
		<a href="http://fedamc.es/index.php?option=com_content&view=article&id=16&Itemid=139">Escuelas Nacionales</a>
	</li>
		<li>
		<a href="http://fedamc.es/index.php?option=com_content&view=article&id=17&Itemid=140">Documentación Federativa</a>
	</li>
		<li>
		<a href="http://fedamc.es/index.php?option=com_content&view=article&id=18&Itemid=141">Te ofrecemos</a>
	</li>
		<li>
		<a href="http://fedamc.es/index.php?option=com_content&view=article&id=19&Itemid=142">Enlaces</a>
	</li>
		<li>
		<a href="http://fedamc.es/index.php?option=com_chronoforms&view=form&Itemid=143">Contacto</a>
	</li>
	</li>
		<li>
		<a href="http://fedamc.es/index.php?option=com_content&view=article&id=20&Itemid=144">Sponsors Oficiales</a>
	</li>
</ul>
                
                                		<div class="cleared"></div>
                    </div>
                </div>
		<div class="cleared"></div>
    </div>
</div>
                          <div class="cleared"></div>
                        </div>
                        <div class="art-layout-cell art-content">
<div class="art-box art-post">
    <div class="art-box-body art-post-body">
<div class="art-post-inner art-article">

<br />
<br />

<div align="center"><img width="575" height="278" border="0" usemap="#Map" src="mapamundo.jpg" style="margin-top: 20px; margin-left: 147px; margin-bottom:22px;">
<map name="Map" id="Map">
  <area shape="circle" coords="259,65,8" href="javascript:" onclick="cargaMapaPais(22)" />
	<area shape="circle" coords="121,117,10" href="javascript:" onclick="cargaMapaPais(21)"/>
  <area shape="circle" coords="98,133,10" href="javascript:" onclick="cargaMapaPais(19)"/>
  <area shape="circle" coords="319,94,10" href="javascript:" onclick="cargaMapaPais(18)" />
  <area shape="circle" coords="109,85,10" href="javascript:" onclick="cargaMapaPais(15)"/>
  <area shape="circle" coords="116,215,9" href="javascript:" onclick="cargaMapaPais(11)"/>
      <area shape="circle" coords="59,115,10" href="javascript:" onclick="cargaMapaPais(4)"/>
      <area shape="circle" coords="122,140,10" href="javascript:" onclick="cargaMapaPais(9)"/>
      <area shape="circle" coords="141,179,10" href="javascript:" onclick="cargaMapaPais(10)"/>
      <area shape="circle" coords="107,150,10" href="javascript:" onclick="cargaMapaPais(5)"/>
      <area shape="circle" coords="97,165,10" href="javascript:" onclick="cargaMapaPais(12)"/>
      <area shape="circle" coords="131,228,10" href="javascript:" onclick="cargaMapaPais(3)"/>
      <area shape="circle" coords="152,227,10" href="javascript:" onclick="cargaMapaPais(20)"/>
      <area shape="circle" coords="264,78,8" href="javascript:" onclick="cargaMapaPais(2)"/>
      <area shape="circle" coords="223,80,10" href="javascript:" onclick="cargaMapaPais(1)"/>
      <area shape="circle" coords="252,53,8" href="javascript:" onclick="cargaMapaPais(6)" />
    <area shape="circle" coords="230,98,10" href="javascript:" onclick="cargaMapaPais(7)" />
<area shape="circle" coords="249,103,10" href="javascript:" onclick="cargaMapaPais(13)" />
<area shape="circle" coords="283,78,10" href="javascript:" onclick="cargaMapaPais(14)" />
<area shape="circle" coords="236,44,10" href="javascript:" onclick="cargaMapaPais(16)" />
<area shape="circle" coords="315,44,10" href="javascript:" onclick="cargaMapaPais(17)" />
<area shape="circle" coords="245,68,8" href="javascript:" onclick="cargaMapaPais(8)" />
<area shape="circle" coords="459,94,520,110" href="javascript:" onclick="cargaMapaPais(23)" />
<area shape="circle" coords="202,265,10" href="http://fedamc.es/index.php?option=com_content&view=category&layout=blog&id=10&Itemid=132" />
  </map>
  <br />
</div>
<div id="resultado" style="width: 779px; margin-left: 84px;"></div>

</div>

</div>

		<div class="cleared"></div>
    </div>
</div>

                          <div class="cleared"></div>
                        </div>
                        <div class="art-layout-cell art-sidebar2">

<div style="margin-left: 518px;">
<p style="width: 384px; text-align: center; height: 79px; margin-left: -142px; font-size: 11px; color:black;">
Polígono Industrial Brenes C/Pilar de los Limones Nº 21 - CP:41410 - Carmona (Sevilla) 
Federación Registrada:Ministerio del Interior, Registro Nacional nº 50775, Grupo 1º, Sección 2 ª<br>
Email de contacto:  <a href="mailto:info@fedamc.es" target="_blank">info@fedamc.es</a>
	</p>
</div>	
                        </div>
                    </div>
                </div>
            </div>
            <div class="cleared"></div>
            <div class="art-footer">
                <div class="art-footer-body">
                            <div class="art-footer-text">
                                <p>Copyright © 2013. All Rights Reserved.</p>
                                                            </div>
                    <div class="cleared"></div>
                </div>
            </div>
    		<div class="cleared"></div>
        </div>
    </div>
    <div class="cleared"></div>
    <p class="art-page-footer"><a href="http://www.dugage.com" target="_blank">Diseño web Sevilla Dugage.</p>
    <div class="cleared"></div>
</div>

</body>
</html>
